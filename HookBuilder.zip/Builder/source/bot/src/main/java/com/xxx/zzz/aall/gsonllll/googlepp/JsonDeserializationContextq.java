

package com.xxx.zzz.aall.gsonllll.googlepp;

import java.lang.reflect.Type;


public interface JsonDeserializationContextq {


  public <T> T deserialize(JsonElementq json, Type typeOfT) throws JsonParseExceptionq;
}