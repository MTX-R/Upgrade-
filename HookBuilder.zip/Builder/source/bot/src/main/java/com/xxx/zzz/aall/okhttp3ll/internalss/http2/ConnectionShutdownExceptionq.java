
package com.xxx.zzz.aall.okhttp3ll.internalss.http2;

import java.io.IOException;


public final class ConnectionShutdownExceptionq extends IOException {
}
