

package com.xxx.zzz.aall.gsonllll.googlepp.internalbb;

import com.xxx.zzz.aall.gsonllll.googlepp.streamss.JsonReaderq;

import java.io.IOException;


public abstract class JsonReaderInternalAccessq {
  public static JsonReaderInternalAccessq INSTANCE;


  public abstract void promoteNameToValue(JsonReaderq reader) throws IOException;
}
