

package com.xxx.zzz.aall.gsonllll.googlepp.internalbb;


public final class GsonBuildConfigq {



  public static final String VERSION = "2.9.0";

  private GsonBuildConfigq() { }
}
