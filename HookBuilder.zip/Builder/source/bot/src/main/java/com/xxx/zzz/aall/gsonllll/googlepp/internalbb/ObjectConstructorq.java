

package com.xxx.zzz.aall.gsonllll.googlepp.internalbb;


public interface ObjectConstructorq<T> {


  public T construct();
}