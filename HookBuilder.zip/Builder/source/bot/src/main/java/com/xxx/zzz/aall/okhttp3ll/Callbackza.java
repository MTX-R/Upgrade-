
package com.xxx.zzz.aall.okhttp3ll;

import java.io.IOException;

public interface Callbackza {
  
  void onFailure(Callzadasd call, IOException e);

  
  void onResponse(Callzadasd call, Responseza response) throws IOException;
}
