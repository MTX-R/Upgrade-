

package com.xxx.zzz.aall.gsonllll.googlepp;

import java.lang.reflect.Field;


public interface FieldbNamingbStrategyq {

  
  public String translateName(Field f);
}
