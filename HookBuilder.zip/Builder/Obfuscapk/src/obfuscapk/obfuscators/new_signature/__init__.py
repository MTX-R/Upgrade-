#!/usr/bin/env python3

from .new_signature import NewSignature
