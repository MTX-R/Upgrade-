#!/usr/bin/env python3

from .class_rename import ClassRename
